REPORT zmm_pending_po_alv_rpt.

TABLES: ekko, ekpo.

TYPES: BEGIN OF ty_po_line,
         ebeln     TYPE ekko-ebeln,
         ebelp     TYPE ekpo-ebelp,
         werks     TYPE ekpo-werks,
         ekgrp     TYPE ekko-ekgrp,
         bedat     TYPE ekko-bedat,
         menge     TYPE ekpo-menge,
         wemng     TYPE ekpo-wemng,
         open_qty  TYPE ekpo-menge,
       END OF ty_po_line.

DATA: gt_po_list   TYPE STANDARD TABLE OF ty_po_line,
      gs_po_line   TYPE ty_po_line,
      lo_alv       TYPE REF TO cl_salv_table,
      lo_functions TYPE REF TO cl_salv_functions_list.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
SELECT-OPTIONS: s_werks FOR ekpo-werks,
                s_ekgrp FOR ekko-ekgrp,
                s_bedat FOR ekko-bedat.
SELECTION-SCREEN END OF BLOCK b1.

START-OF-SELECTION.

  SELECT ekko~ebeln ekpo~ebelp ekpo~werks ekko~ekgrp
         ekko~bedat ekpo~menge ekpo~wemng
    INTO CORRESPONDING FIELDS OF TABLE gt_po_list
    FROM ekko
    INNER JOIN ekpo ON ekpo~ebeln = ekko~ebeln
    WHERE ekpo~werks IN s_werks
      AND ekko~ekgrp IN s_ekgrp
      AND ekko~bedat IN s_bedat
      AND ekpo~loekz = space.

  LOOP AT gt_po_list INTO gs_po_line.
    gs_po_line-open_qty = gs_po_line-menge - gs_po_line-wemng.
    MODIFY gt_po_list FROM gs_po_line INDEX sy-tabix.
  ENDLOOP.

  PERFORM display_alv.

FORM display_alv.
  TRY.
      CALL METHOD cl_salv_table=>factory
        IMPORTING
          r_salv_table = lo_alv
        CHANGING
          t_table      = gt_po_list.
      CALL METHOD lo_alv->get_functions
        RECEIVING
          value = lo_functions.
      lo_functions->set_all( abap_true ).
      lo_alv->display( ).
    CATCH cx_salv_msg.
      MESSAGE 'ALV display error' TYPE 'I'.
  ENDTRY.
ENDFORM.

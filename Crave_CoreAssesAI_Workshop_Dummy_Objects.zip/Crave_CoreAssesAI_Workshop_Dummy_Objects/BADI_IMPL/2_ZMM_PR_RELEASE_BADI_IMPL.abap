CLASS zcl_im_mm_pr_release_check DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    INTERFACES if_ex_me_process_req_cust.

ENDCLASS.

CLASS zcl_im_mm_pr_release_check IMPLEMENTATION.

  METHOD if_ex_me_process_req_cust~process_item.

    DATA: lv_value      TYPE ekpo-netwr,
          lv_threshold  TYPE zmm_pr_threshold-max_value,
          lv_restricted TYPE abap_bool,
          lv_werks      TYPE ekpo-werks,
          lv_kostl      TYPE ekpo-kostl.

    lv_werks = im_item->get_werks( ).
    lv_kostl = im_item->get_kostl( ).
    lv_value = im_item->get_netwr( ).

    SELECT SINGLE max_value
      INTO lv_threshold
      FROM zmm_pr_threshold
      WHERE werks = lv_werks.

    CLEAR lv_restricted.
    SELECT SINGLE kostl
      INTO lv_kostl
      FROM zmm_restricted_cc
      WHERE kostl = lv_kostl.
    IF sy-subrc = 0.
      lv_restricted = abap_true.
    ENDIF.

    IF lv_value > lv_threshold AND lv_restricted = abap_true.
      im_item->set_error( ).
      MESSAGE e001(zmm_pr) WITH lv_threshold.
    ENDIF.

  ENDMETHOD.

ENDCLASS.

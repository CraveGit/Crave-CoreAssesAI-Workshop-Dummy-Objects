DATA: ls_override TYPE zsd_credit_override,
      lv_today    TYPE sy-datum.

lv_today = sy-datum.

CLEAR ls_override.

SELECT SINGLE *
  INTO ls_override
  FROM zsd_credit_override
  WHERE kunnr      = vbak-kunnr
    AND vkorg       = vbak-vkorg
    AND valid_from <= lv_today
    AND valid_to   >= lv_today.

IF sy-subrc = 0.
  vbak-cmgst = 'Z'.
ENDIF.

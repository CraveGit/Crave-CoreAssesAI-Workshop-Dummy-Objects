REPORT zvendor_rebate_engine.

TYPES: BEGIN OF ty_rebate_calc,
         lifnr      TYPE lifnr,
         agreement  TYPE zvreb_hdr-agreement,
         period     TYPE spmon,
         base_value TYPE wrbtr,
         tier_pct   TYPE p LENGTH 5 DECIMALS 3,
         override   TYPE wrbtr,
         final_amt  TYPE wrbtr,
       END OF ty_rebate_calc.

DATA: gt_calc   TYPE STANDARD TABLE OF ty_rebate_calc,
      gs_calc   TYPE ty_rebate_calc,
      gt_hdr    TYPE STANDARD TABLE OF zvreb_hdr,
      ls_hdr    TYPE zvreb_hdr,
      gt_itm    TYPE STANDARD TABLE OF zvreb_itm,
      ls_itm    TYPE zvreb_itm,
      gt_cond   TYPE STANDARD TABLE OF zvreb_cond,
      lv_base   TYPE wrbtr,
      lv_calc   TYPE wrbtr.

PARAMETERS: p_period TYPE spmon OBLIGATORY.

START-OF-SELECTION.

  SELECT * INTO TABLE gt_hdr
    FROM zvreb_hdr
    WHERE valid_from <= p_period
      AND valid_to   >= p_period.

  LOOP AT gt_hdr INTO ls_hdr.

    SELECT * INTO TABLE gt_itm
      FROM zvreb_itm
      WHERE agreement = ls_hdr-agreement.

    LOOP AT gt_itm INTO ls_itm.

      CALL FUNCTION 'ZFM_REBATE_GET_PURCHASE_VALUE'
        EXPORTING
          iv_lifnr  = ls_hdr-lifnr
          iv_matkl  = ls_itm-matkl
          iv_period = p_period
        IMPORTING
          ev_value  = lv_base.

      CLEAR gs_calc-override.
      SELECT SINGLE override_value
        INTO gs_calc-override
        FROM zvreb_cond
        WHERE lifnr = ls_hdr-lifnr
          AND matkl = ls_itm-matkl.

      IF gs_calc-override IS NOT INITIAL.
        lv_calc = gs_calc-override.
      ELSE.
        lv_calc = lv_base * ls_itm-rebate_pct / 100.
      ENDIF.

      gs_calc-lifnr      = ls_hdr-lifnr.
      gs_calc-agreement  = ls_hdr-agreement.
      gs_calc-period     = p_period.
      gs_calc-base_value = lv_base.
      gs_calc-tier_pct   = ls_itm-rebate_pct.
      gs_calc-final_amt  = lv_calc.

      APPEND gs_calc TO gt_calc.
    ENDLOOP.
  ENDLOOP.

  MODIFY zvreb_result FROM TABLE gt_calc.
  PERFORM write_audit_log.

FORM write_audit_log.
ENDFORM.

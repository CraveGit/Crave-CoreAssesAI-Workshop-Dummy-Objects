REPORT zpp_adv_scheduling_optimizer.

TYPES: BEGIN OF ty_order_seq,
         aufnr          TYPE aufnr,
         arbpl          TYPE arbpl,
         seq_no         TYPE i,
         start_dt       TYPE dats,
         start_tm       TYPE tims,
         changeover_min TYPE i,
       END OF ty_order_seq.

DATA: gt_orders    TYPE STANDARD TABLE OF ty_order_seq,
      ls_order     TYPE ty_order_seq,
      gt_capacity  TYPE STANDARD TABLE OF zpp_capacity,
      gt_seqrules  TYPE STANDARD TABLE OF zpp_seq_rules,
      ls_rule      TYPE zpp_seq_rules,
      gt_constr    TYPE STANDARD TABLE OF zpp_constraints,
      gv_best_cost TYPE i VALUE 999999,
      gv_cost      TYPE i.

PARAMETERS: p_werks TYPE werks_d OBLIGATORY,
            p_dat1  TYPE dats OBLIGATORY,
            p_dat2  TYPE dats OBLIGATORY.

START-OF-SELECTION.

  SELECT aufnr arbpl
    INTO CORRESPONDING FIELDS OF TABLE gt_orders
    FROM afko
    WHERE werks = p_werks
      AND gstrp BETWEEN p_dat1 AND p_dat2.

  SELECT * INTO TABLE gt_capacity FROM zpp_capacity WHERE werks = p_werks.
  SELECT * INTO TABLE gt_seqrules FROM zpp_seq_rules.
  SELECT * INTO TABLE gt_constr FROM zpp_constraints WHERE werks = p_werks.

  PERFORM run_optimizer_heuristic.
  PERFORM write_result_and_log.

FORM run_optimizer_heuristic.
  CLEAR gv_cost.
  LOOP AT gt_orders INTO ls_order.
    LOOP AT gt_seqrules INTO ls_rule.
      gv_cost = gv_cost + ls_rule-changeover_min.
    ENDLOOP.
    IF gv_cost < gv_best_cost.
      gv_best_cost = gv_cost.
    ENDIF.
  ENDLOOP.
ENDFORM.

FORM write_result_and_log.
ENDFORM.
